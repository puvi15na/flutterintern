import 'package:flutter/material.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Calculator(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Calculator extends StatefulWidget {
  @override
  _CalculatorState createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  TextEditingController num1 = TextEditingController();
  TextEditingController num2 = TextEditingController();
  double result = 0;

  void add() {
    setState(() {
      result = double.parse(num1.text) + double.parse(num2.text);
    });
  }

  void subtract() {
    setState(() {
      result = double.parse(num1.text) - double.parse(num2.text);
    });
  }

  void multiply() {
    setState(() {
      result = double.parse(num1.text) * double.parse(num2.text);
    });
  }

  void divide() {
    setState(() {
      result = double.parse(num1.text) / double.parse(num2.text);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Simple Calculator")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: num1,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Enter first number"),
            ),
            TextField(
              controller: num2,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Enter second number"),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(onPressed: add, child: Text("+")),
                ElevatedButton(onPressed: subtract, child: Text("-")),
                ElevatedButton(onPressed: multiply, child: Text("*")),
                ElevatedButton(onPressed: divide, child: Text("/")),
              ],
            ),
            SizedBox(height: 20),
            Text("Result: $result", style: TextStyle(fontSize: 20)),
          ],
        ),
      ),
    );
  }
}
