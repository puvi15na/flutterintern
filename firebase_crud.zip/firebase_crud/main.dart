import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CrudScreen(),
    );l
  }
}

class CrudScreen extends StatefulWidget {
  @override
  _CrudScreenState createState() => _CrudScreenState();
}

class _CrudScreenState extends State<CrudScreen> {
  final TextEditingController nameController = TextEditingController();
  final CollectionReference users =
      FirebaseFirestore.instance.collection('users');

  // Create
  Future<void> addUser(String name) {
    return users.add({'name': name});
  }

  // Read
  Stream<QuerySnapshot> getUsers() {
    return users.snapshots();
  }

  // Update
  Future<void> updateUser(String docId, String newName) {
    return users.doc(docId).update({'name': newName});
  }

  // Delete
  Future<void> deleteUser(String docId) {
    return users.doc(docId).delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Flutter Firebase CRUD')),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8.0),
            child: TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: 'Enter Name'),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              if (nameController.text.isNotEmpty) {
                addUser(nameController.text);
                nameController.clear();
              }
            },
            child: Text('Add User'),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: getUsers(),
              builder: (context, snapshot) {
                if (!snapshot.hasData)
                  return Center(child: CircularProgressIndicator());
                return ListView(
                  children: snapshot.data!.docs.map((doc) {
                    String userName = doc['name'];
                    return ListTile(
                      title: Text(userName),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit),
                            onPressed: () {
                              TextEditingController updateController =
                                  TextEditingController(text: userName);
                              showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: Text('Edit User'),
                                  content:
                                      TextField(controller: updateController),
                                  actions: [
                                    TextButton(
                                      onPressed: () {
                                        updateUser(
                                            doc.id, updateController.text);
                                        Navigator.pop(context);
                                      },
                                      child: Text('Update'),
                                    )
                                  ],
                                ),
                              );
                            },
                          ),
                          IconButton(
                            icon: Icon(Icons.delete),
                            onPressed: () => deleteUser(doc.id),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
